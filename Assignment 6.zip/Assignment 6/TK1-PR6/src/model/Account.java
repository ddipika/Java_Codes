/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import gui.AccountInfoPanel;
import gui.MainWindow;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author floriment
 */
public class Account implements Runnable {

    private int port;
    private Integer amount;
    private MainWindow mainWindow;
    private AccountInfoPanel accountPanel;
    private Map<String, Map<Integer, State>> states = new ConcurrentHashMap<>();
    private AtomicInteger snapshotCounter = new AtomicInteger(0);
    private static final int LOWER_BOUND = 5000;
    private static final int UPPER_BOUND = 10000;

    public MainWindow getMainWindow() {
        return mainWindow;
    }

    public void setMainWindow(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
    }

    public AccountInfoPanel getAccountPanel() {
        return accountPanel;
    }

    public void setAccountPanel(AccountInfoPanel accountPanel) {
        this.accountPanel = accountPanel;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private DatagramSocket serverSocket;
    private Map<String, CommunicationChannel> channels = new HashMap<String, CommunicationChannel>();
    private Random rand = new Random();

    public void addCommunicationChannel(String key, CommunicationChannel comChannel) {
        channels.put(key, comChannel);
        states.put(key, new ConcurrentHashMap<>());
    }

    public Account(String name, int initialAmount, int port) {
        this.name = name;
        this.amount = initialAmount;
        this.port = port;
        states.put(name, new ConcurrentHashMap<>());
        try {
            serverSocket = new DatagramSocket(this.port);
        } catch (SocketException ex) {
            Logger.getLogger(Account.class.getName()).log(Level.SEVERE, null,
                    ex);
        }
    }

    public void run() {
        for (Map.Entry<String, CommunicationChannel> entrySet : channels
                .entrySet()) {
            String key = entrySet.getKey();
            CommunicationChannel comChannel = entrySet.getValue();
            new Thread(comChannel).start();
            new Thread() {

                @Override
                public void run() {
                    while (true) {
                        try {
                            Thread.sleep(CommunicationChannel.getRandomDelay());
                        } catch (InterruptedException ex) {
                            Logger.getLogger(Account.class.getName()).log(
                                    Level.SEVERE, null, ex);
                        }
                        int randomAmount = 5 + rand.nextInt(55);
                        synchronized (amount) {
                            if (getAmount() - randomAmount > 0) {
                                synchronized (channels) {
                                    transfer(key, randomAmount);
                                }
                            }
                        }

                    }
                }

            }.start();
        }

        byte[] receiveData = new byte[1024];
        byte[] sendData = new byte[1024];
        while (true) {
            DatagramPacket receivePacket = new DatagramPacket(receiveData,
                    receiveData.length);
            try {
                serverSocket.receive(receivePacket);
            } catch (IOException ex) {
                Logger.getLogger(Account.class.getName()).log(Level.SEVERE,
                        null, ex);
            }
            String message = new String(receivePacket.getData());
            String[] messageSplited = message.split(":");
            if (messageSplited[0].equals("M")) {
                markerReceived(messageSplited[1], messageSplited[2],
                        new Integer(messageSplited[3].trim()));
            } else {
                int value = new Integer(messageSplited[2].trim());
                
                recordMessage("+ " + value + " €", messageSplited[1]);
                messageReceived(messageSplited[1], value);
            }
        }
    }

    public void randomlySend() {

    }

    public void messageReceived(String accountName, int value) {
        synchronized (amount) {
            this.amount += value;
        }
        
        this.accountPanel.refresh();
        this.mainWindow.printMessage("Received: " + accountName + " => "
                + this.getName() + "(" + value + " €). New account balance of " + this.getName() + "=" + amount);
    }

    public void transfer(String id, int value) {
        this.amount -= value;
        this.accountPanel.refresh();
        this.mainWindow.printMessage("Sending: " + this.getName() + " => " + id
                + "( - " + value + " €). New account balance of " + this.getName() + "=" + amount);
        String message = "T:" + getName() + ":" + value;
        channels.get(id).addMessageToQueue(message);
    }

    public void markerReceived(String accountName, String initiator,
            int markerNumber) {
        mainWindow.printMessage(getName() + " marker received from: "
                + accountName + " with initiator:" + initiator
                + " and marker number:" + markerNumber);

        if (!states.get(initiator).containsKey(markerNumber)) {
            
            synchronized (channels) {
                //saving the state
                State state = new State();
                state.setAmount(amount);
                states.get(initiator).put(markerNumber, state);
                
                mainWindow.printMessage(getName() + " recorded state (" + amount + ") for snapshot with initiator:" + initiator
                        + " and marker number:" + markerNumber);

                for (Map.Entry<String, CommunicationChannel> entry : channels.entrySet()) {
                    String recipient = entry.getKey();
                    if (!accountName.equals(recipient)) {
                    	Recordings recs = new Recordings();
                    	recs.setRecord(true);
                    	
                        state.getRecordings().put(recipient, recs);
                        
                        mainWindow.printMessage(getName() + " starts recording input channel from " + recipient);
                    }
                    sendMarker(recipient, initiator, markerNumber);
                }

            }
        } else {
            State state = states.get(initiator).get(markerNumber);
            state.getRecordings().get(accountName).setRecord(false);
            mainWindow.printMessage(getName() + " stops recording input channel from " + accountName);
            
            
            Map<String,Recordings> allRec = state.getRecordings();
            boolean answer = true;
            for (Map.Entry<String, Recordings> entrySet : allRec.entrySet()) {
                Recordings recording = entrySet.getValue();
                if(recording.isRecord()){
                    answer = false;
                    break;
                }
            }
            if(answer){
                StringBuilder sb = new StringBuilder();
                sb.append(getName()).append(" recorded state for snapshot ");
                sb.append(markerNumber);
                sb.append(" from ");
                sb.append(initiator).append(":\n");
                
                sb.append("value=");
                sb.append(state.getAmount());
                sb.append("\n");
                for (Map.Entry<String, Recordings> entrySet : allRec.entrySet()) {
                    String channelName = entrySet.getKey();
                    Recordings recordings = entrySet.getValue();
                    sb.append("channel from ");
                    sb.append(channelName);
                    sb.append(" = ");
                    sb.append(recordings.getMessages());
                    sb.append("\n");
                }
                mainWindow.printMessage(sb.toString());
            }
        }
    }

    public void startSnapshot() {

        markerReceived(getName(), getName(), snapshotCounter.incrementAndGet());
    }

    public void sendMarker(String id, String initiator, int markerNumber) {
        channels.get(id).addMessageToQueue(
                "M:" + getName() + ":" + initiator + ":" + markerNumber);
        mainWindow.printMessage("marker sent from: " + getName() + " to: " + id
                + " with initiator:" + initiator + " and marker number:"
                + markerNumber);

    }

    private void recordMessage(String message, String sender) {
        
        for (Map.Entry<String, Map<Integer, State>> entry : states.entrySet()) {
            String initiator = entry.getKey();
            Map<Integer, State> states = entry.getValue();
            for (Map.Entry<Integer, State> entry2 : states.entrySet()) {
                Integer markerNumber = entry2.getKey();
                State state = entry2.getValue();
                Recordings rec = state.getRecordings().get(sender);
                if(rec != null && rec.isRecord())
                {
                    rec.getMessages().add(message);
                }
            }
            
        }
        
    }

}
