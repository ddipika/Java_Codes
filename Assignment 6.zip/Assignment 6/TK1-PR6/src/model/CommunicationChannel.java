/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.AbstractQueue;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author floriment
 */
public class CommunicationChannel implements Runnable {

    private Queue<String> messages = new ConcurrentLinkedQueue<>(new LinkedList<>());
    private int port_dst;
    private DatagramSocket clientSocket;
    private Account source;
    private static final int LOWER_BOUND = 1000;
    private static final int UPPER_BOUND = 5000;
    private static Random rand = new Random();

    public CommunicationChannel(Account source, int port) {
        this.port_dst = port;
        this.source = source;
        try {
            clientSocket = new DatagramSocket();
        } catch (SocketException ex) {
            Logger.getLogger(CommunicationChannel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void addMessageToQueue(String message) {
        messages.add(message);
    }

    public static int getRandomDelay() {
        return rand.nextInt(UPPER_BOUND - LOWER_BOUND) + LOWER_BOUND;
    }

    public void run() {
        while (true) {
            try {
                if (!messages.isEmpty()) {
                    BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
                    InetAddress IPAddress = InetAddress.getByName("localhost");
                    byte[] sendData = new byte[1024];
                    String value = messages.poll();
//                    if(value == "marker"){}
//                    String message = source.getName() + ":" + value;
                    sendData = value.getBytes();
                    final DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, IPAddress, port_dst);
                    try {
                        Thread.sleep(getRandomDelay());
                        clientSocket.send(sendPacket);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(CommunicationChannel.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            } catch (IOException e) {
                System.out.println("Exception: " + e.getMessage());
            }
        }
    }
}
