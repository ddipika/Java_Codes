/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author floriment
 */
public class AccountInitializer {

    private static final int LOWER_BOUND = 500;
    private static final int UPPER_BOUND = 1000;
    private static Random rand = new Random();

    private static List<Account> accounts = new ArrayList<>();

    public static List<Account> getAccounts() {
        return accounts;
    }

    public static int getRandomAmount() {
        return rand.nextInt(UPPER_BOUND - LOWER_BOUND) + LOWER_BOUND;

    }

    public static void initAccounts() {
        Account account1 = new Account("k1", getRandomAmount(), 9999);
        Account account2 = new Account("k2", getRandomAmount(), 9998);
        Account account3 = new Account("k3", getRandomAmount(), 9997);

        CommunicationChannel c12 = new CommunicationChannel(account1, 9998);
        CommunicationChannel c13 = new CommunicationChannel(account1, 9997);
        account1.addCommunicationChannel("k2", c12);
        account1.addCommunicationChannel("k3", c13);

        CommunicationChannel c21 = new CommunicationChannel(account2, 9999);
        CommunicationChannel c23 = new CommunicationChannel(account2, 9997);
        account2.addCommunicationChannel("k1", c21);
        account2.addCommunicationChannel("k3", c23);

        CommunicationChannel c31 = new CommunicationChannel(account3, 9999);
        CommunicationChannel c32 = new CommunicationChannel(account3, 9998);
        account3.addCommunicationChannel("k1", c31);
        account3.addCommunicationChannel("k2", c32);


        accounts.add(account1);
        accounts.add(account2);
        accounts.add(account3);
    }

    public static void startSimulation(){
        for(Account account : accounts)
        {
            new Thread(account).start();
        }
    }
}
