/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author floriment
 */
public class State {

    private int amount;
    private Map<String, Recordings> recordings = new ConcurrentHashMap<>();
    
    public Map<String, Recordings> getRecordings() {
        return recordings;
    }

    public void setRecordings(Map<String, Recordings> recordings) {
        this.recordings = recordings;
    }

    public State() {
        
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }


}
